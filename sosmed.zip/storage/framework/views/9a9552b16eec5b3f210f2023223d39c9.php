 <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="interaction-button" id="interaction-detail-<?php echo e($post->id); ?>">
    <div class="like">

        <form hx-post="like/<?php echo e($post->id); ?>"
            hx-target="#interaction-detail-<?php echo e($post->id); ?>">
            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($like->likes == 'false' && $like->post_id == $post->id): ?>
                    <button type="submit" class="interaction-button-detail"><i
                            class="fa-regular fa-thumbs-up fa-2x"></i></button>
                <?php elseif($like->likes == 'true' && $like->post_id == $post->id): ?>
                    <button type="submit" class="interaction-button-detail"><i
                            class="fa-solid fa-thumbs-up fa-2x"></i></button>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <button type="submit"><i
                    class="fa-regular fa-thumbs-up fa-2x"></i></button>
        </form>
        
        <p><?php echo e($post->likes); ?></p>
    </div>
    <div class="dislike">
        <form hx-post="dislike/<?php echo e($post->id); ?>"
            hx-target="#interaction-detail-<?php echo e($post->id); ?>">
            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($like->dislikes == 'false' && $like->post_id == $post->id): ?>
                <button type="submit" class="interaction-button-detail"><i
                        class="fa-regular fa-thumbs-down fa-2x"></i></button>
            <?php elseif($like->dislikes == 'true' && $like->post_id == $post->id): ?>
                <button type="submit" class="interaction-button-detail"><i
                        class="fa-solid fa-thumbs-down fa-2x"></i></button>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button type="submit"><i
                class="fa-regular fa-thumbs-down fa-2x"></i></button>
        </form>
        <p><?php echo e($post->dislikes); ?></p>
    </div>
    <div class="share">
        <i class="fa-solid fa-share"></i>
        <p><?php echo e($post->shares); ?></p>
    </div>
    <p> <?php echo e($post->total_comment); ?> komentar</p>
</div>
     <p>Komentar</p>
     <div class="comment-list">
         <b>
             <p> <?php echo e($post->post_commenter); ?></p>
         </b>
         <p><?php echo e($post->post_comment); ?> </p>
     </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\Users\rahmat\sosmed\resources\views/partials/comment.blade.php ENDPATH**/ ?>