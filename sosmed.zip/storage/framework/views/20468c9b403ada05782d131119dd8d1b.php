<p><?php echo e($post->post_title); ?></p>

<p><?php echo e($post->post_content); ?></p>
<div class="interaction-button">
    <div class="like">
        <i class="fa-solid fa-circle-up"></i>
        <p><?php echo e($post->like); ?></p>
    </div>

    <div class="dislike">
        <i class="fa-solid fa-circle-down"></i>
        <p><?php echo e($post->dislike); ?></p>
    </div>
    <div class="share">
        <i class="fa-solid fa-share"></i>
        <p><?php echo e($post->share); ?></p>
    </div>
    <p> <?php echo e($post->total_comment); ?> komentar</p>
</div>

<div class="comment-section">

    <div class="comment-list">

        <b>
            <p> <?php echo e($post->post_commenter); ?></p>
        </b>

        <p><?php echo e($post->post_comment); ?> </p>
    </div>


</div>
<div class="add-comment-container">
    <form hx-post="comment" hx-target="#post-detail" hx-swap="innerHTML">
        <?php echo csrf_field(); ?>
        <input name="post_id" value="<?php echo e($post->id); ?>">
        <input name="comment" type="text">
        <button type="submit">Send</button>
    </form>
</div>
<?php /**PATH C:\Users\rahmat\sosmed\resources\views////partials/comment.blade.php ENDPATH**/ ?>