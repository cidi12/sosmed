<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="like">
        <form hx-post="like/<?php echo e($post->id); ?>" hx-target="#interaction-detail-<?php echo e($post->id); ?>">
            <?php echo csrf_field(); ?>
            <?php if($like->likes == 'false' ): ?>
            <button type="submit"><i class="fa-regular fa-thumbs-up fa-2x"></i></button>
            <?php else: ?>
            <button type="submit"><i class="fa-solid fa-thumbs-up fa-2x"></i></button>
            <?php endif; ?>
           
        </form>
        <p><?php echo e($post->likes); ?></p>
    </div>
    <div class="dislike">
        <form hx-post="dislike/<?php echo e($post->id); ?>" hx-target="#interaction-detail-<?php echo e($post->id); ?>">
            <?php echo csrf_field(); ?>
            <?php if($like->dislikes == 'false' ): ?>
            <button type="submit"><i class="fa-regular fa-thumbs-down fa-2x"></i></button>
            <?php else: ?>
            <button type="submit"><i class="fa-solid fa-thumbs-down fa-2x"></i></button>
            <?php endif; ?>
            
        </form>
        <p><?php echo e($post->dislikes); ?></p>
    </div>
    <div class="share">
        <i class="fa-solid fa-share"></i>
        <p><?php echo e($post->shares); ?></p>
    </div>
    <p> <?php echo e($post->total_comment); ?> komentar</p>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\rahmat\sosmed\resources\views/partials/interaction.blade.php ENDPATH**/ ?>